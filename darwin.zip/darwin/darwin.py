import requests
from bs4 import BeautifulSoup
from selenium import webdriver
import pandas as pd
import time

driver = webdriver.Chrome('/home/sandip/buildmeasure/darwin/driver/chromedriver')

df = pd.DataFrame({'job_link': [], 'job_title': [], 'job_type': [], 'job_location': [], 'salary': [], 'job_description': []})

for page_num in range(1, 48):
    url = f'https://www.darwinrecruitment.com/search-jobs/?_paged={page_num}'
    driver.get(url)
    soup = BeautifulSoup(driver.page_source, 'lxml')

    postings = soup.find_all('div', class_='col-md-4 darwin_job_search_page_row darwin_job_search_page_jobs_boxes')
    
    for post in postings:
        container = post.find_parent('a')  # Find the parent anchor tag that contains both job title and link
        job_link = container.get('href') if container else ''
        job_title = post.find('h2', class_='darwin_job_search_page_job_title').text.strip() if post.find('h2', class_='darwin_job_search_page_job_title') else ''
        
        job_type = post.find('h4', class_='col-md-6 darwin_job_search_page_job_type').text.strip() if post.find('h4', class_='col-md-6 darwin_job_search_page_job_type') else ''
        try:
            job_location = post.find('h2', class_='darwin_job_search_page_job_location').text.strip() if post.find('h2', class_='darwin_job_search_page_job_location') else ''
        except:
            job_location = 'N/A'
        try:
            salary = post.find('h4', class_='col-md-6 darwin_job_search_page_salary').text.strip()
        except AttributeError:
            salary = 'N/A'
        
        job_description = post.find('p', class_='darwin_job_search_page_job_description').text.strip() if post.find('p', class_='darwin_job_search_page_job_description') else ''
    
        df = df.append({
            'job_link': job_link,
            'job_title': job_title,
            'job_type': job_type,
            'job_location': job_location,
            'salary': salary,
            'job_description': job_description
        }, ignore_index=True)
        
driver.quit()
print(df)

df.to_csv(r'darwinData.csv', index = False)



