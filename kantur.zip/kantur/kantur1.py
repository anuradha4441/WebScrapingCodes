import requests
from selenium import webdriver
from bs4 import BeautifulSoup
import pandas as pd
import time

driver = webdriver.Chrome('/home/sandip/buildmeasure/darwin/driver/chromedriver')

driver.get('https://kantur.se/leads/')

# Introduce a delay to allow the page to load
time.sleep(2)

soup = BeautifulSoup(driver.page_source, 'lxml')

df = pd.DataFrame({'job_title': [], 'job_description': []})

postings = soup.find_all('tr', class_='tr-summary-elem-test')

for post in postings:
    job_title = post.find('h3', class_='h3-table').text.strip()
    
    # Use .text to get the text content of the tag
    job_description = post.find('p', class_='lead-summary-test').text.strip() if post.find('p', class_='lead-summary-test') else 'N/A'
    
    df = df.append({
        'job_title': job_title,
        'job_description': job_description
    }, ignore_index=True)

driver.quit()
print(df)   
df.to_csv(r'kantur.csv', index = False)
    
