import requests
from bs4 import BeautifulSoup
import pandas as pd

url = 'https://kantur.se/leads/'

page = requests.get(url)
page.text

soup = BeautifulSoup(page.text, 'lxml')
soup

html = BeautifulSoup(page.text, 'lxml')
html

job_title = soup.find_all('h3',class_ = 'h3-table')
job_title

job_discription = soup.find_all('p',class_ ='lead-summary-test')
job_discription

job_title_list = []
for i in job_title:
    job_title = i.text
    job_title_list.append(job_title)
    
job_discription_list = []
for i in job_discription:
    job_discription = i.text
    job_discription_list.append(job_discription)
    
table = pd.DataFrame({'job_title':job_title_list,'job_discription':job_discription_list})


    