# 
import requests
from selenium import webdriver
from bs4 import BeautifulSoup
import pandas as pd
import time

driver = webdriver.Chrome('/home/sandip/buildmeasure/darwin/driver/chromedriver')

driver.get('https://careers.koalitionen.com/jobs')

soup = BeautifulSoup(driver.page_source, 'lxml')

postings = soup.find_all('a', class_ = 'w-full')
len(postings)

df = pd.DataFrame({'job_title':[], 'job_description':[]})

postings = soup.find_all('a', class_ = 'flex flex-col py-6 text-center sm:px-6 hover:bg-gradient-block-base-bg focus-visible-company focus-visible:rounded')

for post in postings:
    job_link = post.get('href')
    job_title = post.find('span', class_ = 'text-block-base-link sm:min-w-[25%] sm:truncate company-link-style').text.strip()
    job_description = post.find('div', class_ = 'mt-1 text-md').text.strip()
    df = df.append({'job_link': job_link,'job_title': job_title, 'job_description': job_description}, ignore_index = True)
    df.to_csv(r'koalitionen.csv', index = False)
   
   
   

