from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.keys import Keys
from bs4 import BeautifulSoup
import pandas as pd
import time

driver = webdriver.Chrome(
    '/home/sandip/buildmeasure/darwin/driver/chromedriver')
driver.get('https://www.nikita.se/ramavtal/')

# soup = BeautifulSoup(driver.page_source, 'lxml')
# postings = soup.find_all('a',{'class':'open-position-list-link'})

# df = pd.DataFrame({'job_links': [], 'job_title': [], 'posting_dates': []})
# while True:
#     soup = BeautifulSoup(driver.page_source, 'lxml')
#     postings = soup.find_all('a', {'class': 'open-position-list-link'})

#     for post in postings:
#         job_link_element = post.find('a', {'class': 'open-position-list-link'})
#         job_title = post.find('span', {'class': 'open-position-title'})
#         posting_date = post.find('span', {'class': 'open-position-date'})
#         job_link = job_link_element.get('href') if job_link_element else ''
#         job_title_text = job_title.text if job_title else ''
#         posting_date_text = posting_date.text if posting_date else ''

#         # Append data to the DataFrame
#         df = pd.concat([df, pd.DataFrame({
#             'job_links': [job_link],
#             'job_title': [job_title_text],
#             'posting_dates': [posting_date_text]
#         })], ignore_index=True)

#     # Check if the 'next' button is found
#     button = soup.find('a', {'class': 'nextpostslink'})
#     if button and 'href' in button.attrs:
#         try:
#             driver.get('https://www.nikita.se/ramavtal/' + button.get('href'))
#         except:
#             break
#     else:
#         break
counter = 0
while counter < 140:
    
    next_page = soup.find('a', class_ = 'nextpostslink').get('href')
    page = requests.get(next_page)
    soup = BeautifulSoup(page.text, 'lxml') 
    counter += 1
       
# df = pd.DataFrame({'job_links': [], 'job_title': [], 'posting_dates': []})
# while True:
soup = BeautifulSoup(driver.page_source, 'lxml')
postings = soup.find_all('a', {'class': 'open-position-list-link'})
df = pd.DataFrame({'job_links': [], 'job_title': [], 'posting_dates': []})
for post in postings:
    job_link = post.find('a', {'class': 'open-position-list-link'})
    #     job_title = post.find('span', {'class': 'open-position-title'})
    #     posting_date = post.find('span', {'class': 'open-position-date'})
    #     # job_link = job_link_element.get('href') if job_link_element else ''
    #     # job_title_text = job_title.text if job_title else ''
    #     # posting_date_text = posting_date.text if posting_date else ''

    #     # Append data to the DataFrame
    #     df = pd.concat([df, pd.DataFrame({
    #         'job_links': [job_link],
    #         'job_title': [job_title],
    #         'posting_date': [posting_date]
    #     })], ignore_index=True)
    # try:
    #     next_page_link = soup.find('a', {'aria-label': 'next page'}).get('href')
    #     driver.get('https://www.nikita.se/ramavtal/' + next_page_link)
    # except:
    #     break
#     table = pd.DataFrame({'job_link': job_link,'job_title': job_title,'posting_dates': posting_dates}, ignore_index = True)

# #     try:
#         next_page_link = soup.find('a', {'aria-label': 'next page'}).get('href')
#         driver.get('https://www.nikita.se/ramavtal/' + next_page_link)
#     except:
#         break
# df = pd.DataFrame({'job_links': [], 'job_title': [], 'posting_dates': []})
# # while True:
# soup = BeautifulSoup(driver.page_source, 'lxml')
# postings = soup.find_all('a', {'class': 'open-position-list-link'})

# df = pd.DataFrame({'job_links': [], 'job_title': [], 'posting_dates': []})
# while True:
#     soup = BeautifulSoup(driver.page_source, 'lxml')
#     postings = soup.find_all('a', {'class': 'open-position-list-link'})

#     for post in postings:
#         job_link_element = post.find('a', {'class': 'open-position-list-link'})
#         job_title = post.find('span', {'class': 'open-position-title'})
#         posting_date = post.find('span', {'class': 'open-position-date'})

#                     # Check if the elements are found before accessing their attributes
#         job_link = job_link_element.get('href') if job_link_element else ''
#         job_title_text = job_title.text if job_title else ''
#         posting_date_text = posting_date.text if posting_date else ''

#                     # Append data to the DataFrame
#         df = pd.concat([df, pd.DataFrame({
#             'job_links': [job_link],
#             'job_title': [job_title_text],
#             'posting_dates': [posting_date_text]
#             })], ignore_index=True)

#         try:
#             button = soup.find('a', attrs = {'aria-label':'next page'}).get('href')
#             driver.get('https://www.nikita.se/ramavtal/')
#         except:
#             break

    # job_links_elements = soup.find_all('a', {'class': 'open-position-list-link'})
    # job_links_list = []

    # for link_element in job_links_elements:
    #     job_link = link_element.get('href')
    #     job_links_list.append(job_link)

    # job_title = soup.find_all('span', {'class': 'open-position-title'})
    # posting_date = soup.find_all('span', {'class': 'open-position-date'})

    # job_title_list = []
    # for i in job_title:
    #     job_title = i.text
    #     job_title_list.append(job_title)

    # posting_date_list = []
    # for i in posting_date:
    #     posting_date = i.text
    #     posting_date_list.append(posting_date)

    # table = pd.DataFrame({'job_links': job_links_list, 'job_title': job_title_list, 'posting_date': posting_date_list})


#     button = soup.find('ä', attrs = {'aria-label': 'next page'}).get('href')
#     driver.get('https://www.nikita.se/ramavtal/')
# # table.to_csv(r'nikita.csv', index = False)
