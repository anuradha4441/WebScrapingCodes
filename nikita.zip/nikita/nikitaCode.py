#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Nov 22 10:27:26 2023

@author: Anuradha
"""

import requests
import time
from bs4 import BeautifulSoup
from selenium import webdriver
import pandas as pd

url = 'https://www.nikita.se/lediga-uppdrag/'

driver = webdriver.Chrome('/home/sandip/buildmeasure/darwin/driver/chromedriver')

driver.get(url)

soup = BeautifulSoup(driver.page_source, 'lxml')


df = pd.DataFrame({'link': [], 'job_title': [], 'posting_date': []})

counter = 0
while counter < 140:
    postings = soup.find_all('li', class_='open-position-item opened')
    
    for post in postings:
        link = post.find('a', class_='open-position-list-link').get('href')
        job_title = post.find('span', class_='open-position-title').text.strip()
        posting_date = post.find('span', class_='open-position-date').text.strip()
        df = df.append({'link': link, 'job_title': job_title, 'posting_date': posting_date}, ignore_index=True)

    driver.find_element_by_class_name('nextpostslink').click()
    time.sleep(2)

    soup = BeautifulSoup(driver.page_source, 'lxml') 
    counter += 1
    df.to_csv(r'nikitaData.csv', index = False)
