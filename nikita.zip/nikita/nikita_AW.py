
"""
Below code is used to extract the data from a single page only!
"""

import requests
from bs4 import BeautifulSoup
import pandas as pd

url = 'https://www.nikita.se/lediga-uppdrag/'

page = requests.get(url)
page

soup = BeautifulSoup(page.text, 'lxml')
soup 
    
df = pd.DataFrame({'link': [], 'job_title': [], 'posting_date': []})

postings = soup.find_all('li', class_='open-position-item opened')

for post in postings:
    link = post.find('a', class_='open-position-list-link').get('href')
    job_title = post.find('span', class_='open-position-title').text.strip()
    posting_date = post.find('span', class_='open-position-date').text.strip()
    df = df.append({'link': link, 'job_title': job_title, 'posting_date': posting_date}, ignore_index=True)
    

"""
Here I try to extract the data from multiple pages.
"""

import requests
from bs4 import BeautifulSoup
import pandas as pd

url = 'https://www.nikita.se/lediga-uppdrag/'

page = requests.get(url)
page

soup = BeautifulSoup(page.text, 'lxml')
soup 

df = pd.DataFrame({'link': [], 'job_title': [], 'posting_date': []})

counter = 0
while counter < 140:
    postings = soup.find_all('li', class_='open-position-item opened')
    
    for post in postings:
        link = post.find('a', class_='open-position-list-link').get('href')
        job_title = post.find('span', class_='open-position-title').text.strip()
        posting_date = post.find('span', class_='open-position-date').text.strip()
        df = df.append({'link': link, 'job_title': job_title, 'posting_date': posting_date}, ignore_index=True)
    next_page = soup.find('a', class_ = 'nextpostslink').get('href')
    page = requests.get(next_page)
    soup = BeautifulSoup(page.text, 'lxml') 
    counter += 1
           



